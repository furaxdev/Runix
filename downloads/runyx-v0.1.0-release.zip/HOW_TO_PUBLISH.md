# How to publish this release

I (Claude, in the cloud sandbox) can't push tags or create releases on
this repo from here (tag push gets HTTP 403, and I have no write-capable
release API). Everything is prepared below — your agent/you just need
to run this from a machine with real `gh`/git push access.

## 0. Prerequisite

This is built from `ccr-8047f90c-ur2jz8` (PR #1), commit `4335a88`.
**PR #1 should be merged into `main` first** (or at least, `main` should
contain this commit) before tagging, so the tag points at something
that's actually on `main`.

## 1. Tag and push

```bash
git fetch origin
git checkout main
git pull origin main
git tag -a v0.1.0 -m "Runyx v0.1.0" 4335a88a44c0ff9bd179cd153759f172060c05f2
git push origin v0.1.0
```

(If `main`'s HEAD after merging PR #1 is a different commit than
`4335a88` — e.g. GitHub creates a merge commit — tag that HEAD commit
instead: `git tag -a v0.1.0 -m "Runyx v0.1.0" main` right after pulling.)

## 2. Create the release with gh CLI

```bash
cd /path/to/this/release/folder   # the folder with the 6 archives + SHA256SUMS.txt

gh release create v0.1.0 \
  runyx-linux-amd64.tar.gz \
  runyx-linux-arm64.tar.gz \
  runyx-darwin-amd64.tar.gz \
  runyx-darwin-arm64.tar.gz \
  runyx-windows-amd64.zip \
  runyx-windows-arm64.zip \
  SHA256SUMS.txt \
  --repo furaxdev/Runyx \
  --title "Runyx v0.1.0" \
  --notes-file RELEASE_NOTES.md
```

That's it — `gh release create` creates the tag on GitHub too if it
doesn't already exist there, uploads all 7 files as release assets, and
uses `RELEASE_NOTES.md` as the release body.

## Files in this folder

- `RELEASE_NOTES.md` — the release description (what you paste into
  the release body; `gh` above does this automatically via `--notes-file`).
- `runyx-linux-amd64.tar.gz`, `runyx-linux-arm64.tar.gz`,
  `runyx-darwin-amd64.tar.gz`, `runyx-darwin-arm64.tar.gz`,
  `runyx-windows-amd64.zip`, `runyx-windows-arm64.zip` — the 6 binaries,
  statically linked (`CGO_ENABLED=0`), built with
  `-ldflags "-X .../internal/version.Version=v0.1.0 -X .../internal/version.Commit=4335a88 -X .../internal/version.BuildDate=2026-10-24T18:20:59Z"`.
- `SHA256SUMS.txt` — checksums for all 6 archives.

All 6 were smoke-tested (`./runyx version` ran and printed the correct
version string) before being handed off.
